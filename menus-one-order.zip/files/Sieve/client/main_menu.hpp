// Sieve hallway — the main menu: Start Sieve, Settings (Graphics, Controls, Language), the File
// Locator, the Filter Designer, the AI Training Harness, Exit.
//
// Keyboard: Up/Down choose, Enter or Right change or open, Left change back, Esc goes back a
// screen. Mouse: point to choose, click to change (right click changes back), the wheel scrolls
// a drop-down list. Every change is applied at once and saved to sieve-hallway.ini; every
// string comes from the language files (strings.hpp).
#pragma once

#include "app_settings.hpp"
#include "strings.hpp"

#include <SDL3/SDL.h>

#include <filesystem>
#include <string>
#include <utility>
#include <vector>

namespace hallway {

class MainMenu
{
public:
    MainMenu(SDL_Window* window, SDL_Renderer* renderer, AppSettings& settings, std::filesystem::path settings_path, DisplayInfo display);

    enum class Result { Start, Locator, Media, Designer, Harness, Quit };
    Result run();
    // Settings alone, as the hallway's pause menu opens them: the menu starts on the Settings
    // screen, and backing out of it ends the menu instead of going to the main screen.
    Result run_settings()
    {
        screen_ = Screen::Settings;
        row_ = 0;
        settings_only_ = true;
        return run();
    }
    void press(SDL_Keycode key, SDL_Keymod mod); // one key, as if typed (scripting and tests)
    void render();

private:
    enum class Screen { Main, Settings, Graphics, Controls, Language };
    enum class Kind { Action, Toggle, Choice, Number };
    struct Item
    {
        Kind kind;
        std::string id; // also the language key: "item.<id>", and "help.<id>"
    };
    std::vector<Item> items() const;
    std::string value_of(const Item& it) const;
    void change(int dir);        // the selected item: act, toggle, step, or open its list
    void back();
    void open_list(const Item& it);
    void choose_from_list(int index);
    std::vector<std::string> list_labels() const;
    void handle(const SDL_Event& e);
    void save();

    SDL_Window* window_;
    SDL_Renderer* r_;
    AppSettings& s_;
    std::filesystem::path path_;
    DisplayInfo display_;
    Screen screen_ = Screen::Main;
    bool settings_only_ = false;
    int row_ = 0;
    bool done_ = false;
    Result result_ = Result::Quit;
    // An open drop-down list: which item, its highlighted entry and first entry shown.
    std::string list_;
    int list_row_ = 0, list_top_ = 0;
    std::vector<std::pair<SDL_FRect, int>> item_rects_, list_rects_;
    SDL_FRect list_box_{};
    std::vector<LanguageInfo> langs_; // the language files found when the menu opened
    float wheel_ = 0;                 // wheel movement not yet whole notches
};

} // namespace hallway
